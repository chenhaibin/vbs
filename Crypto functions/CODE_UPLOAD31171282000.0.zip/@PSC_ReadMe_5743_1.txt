Title: MD5 Message Digest Algorithms
Description: Various ports of the MD5 RSA Reference Implementation. This includes a VB Native Class, a C DLL (with VB wrapper), and a Java port.
The MD5 algorithm takes as input a message of arbitrary length and produces as output a 128-bit "fingerprint" or "message digest" of the input. It is intended for digital signature applications, where a large file must be "compressed" in a secure manner before being encrypted with a private (secret) key under a public-key cryptosystem such as RSA.
For more information about this algorithm, see the following:
http://www.w3.org/PICS/DSig/RSA-MD5_1_0.html 
http://www.gl.umbc.edu/~mabzug1/cs/md5/md5.html 

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=5743&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
