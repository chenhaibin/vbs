Enclosed in this distribution are four projects:

	MD5DLLTest: Visual basic project which runs the MD5 test suite against a 
		    MD5 DLL (see below).

	VbMD5: A Visual Basic native MD5 message digest class based on the 
               RSA reference implementation.
 
	md5DLL: A 'C' project which generates a simple Win32 DLL with
		the MD5 message digest routines using the RSA reference
		implementation.

	MD5Java: A Java implementation of the MD5 message digest algorithm based
		 on the RSA reference implmentation.


Let me know if this has any use!

Robert M. Hubley
hubley@u.washington.edu
